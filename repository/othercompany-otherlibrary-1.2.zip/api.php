<?php

// Creates the API Request from the context
class APIRequest {
}

// API Response 
class APIResponse {
}

// Api Method Type Constants
class APIMethodType {
}

// API Context that contain info for the API endpoint
class APIContext {
}

?>
